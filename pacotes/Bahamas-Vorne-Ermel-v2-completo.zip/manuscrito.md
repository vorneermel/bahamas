# Bahamas
## A alegria de ir, a felicidade de voltar

Vorne Ermel

### 1. Companheiros de viagem

Do outro lado do corredor do avião, um casal chamou minha atenção. Não demorou para nos apresentarmos: ele era seu João; ela, Cleide. Com eles estava Marcelo, o filho de dez anos. Cleide era psicóloga, e seu João, cirurgião cardíaco. Também estavam a caminho de umas férias nas Bahamas, dispostos a aproveitar aquelas praias tão bonitas.

Aproveitei a apresentação para dizer quem eu era.

— Meu nome é Israel M R. Prazer em conhecer vocês.

Falei sorrindo, acompanhando aquele começo de conversa. Sempre achei curioso como um nome muda a maneira de olhar para alguém. Até poucos instantes antes, eu via um casal e uma criança sentados do outro lado do corredor. Depois das apresentações, passei a ver seu João, Cleide e Marcelo. A distância entre as poltronas continuava a mesma, mas conversar já parecia mais fácil.

Eu também tinha minhas expectativas para aquelas férias. Não precisava contar a vida inteira para explicar isso. Estávamos todos viajando para descansar e desfrutar as praias, e esse assunto já bastava para nos aproximar. Ao ouvir que eles fariam o mesmo, tive aquela sensação agradável de encontrar companhia numa vontade que, até então, era só minha.

Era bom começar a viagem conversando. Em outras circunstâncias, poderíamos ter passado aquelas horas apenas olhando para a frente, cada um fechado em seus pensamentos. Naquele dia, houve espaço para a gentileza de uma apresentação. Uma coisa pequena, sem esforço, que deixou o ambiente mais acolhedor.

Foi uma conversa simples, dessas que começam entre pessoas que vão dividir algumas horas de viagem. Pouco antes, éramos desconhecidos. Agora eu já sabia seus nomes e um pouco do que os levava até ali. Era bom perceber que a minha vontade de descansar encontrava companhia.

À minha direita estava outro casal, de idade avançada. Pelo que pude notar, ele já devia ter passado dos oitenta anos, e ela parecia ter idade próxima à dele. Eram seu Jorge e dona Ana. Conversavam comigo com muita gentileza e um sorriso que parecia não se desfazer.

Enquanto falávamos, eles permaneciam de mãos dadas. De vez em quando, trocavam um carinho. Aquilo me chamou a atenção mais do que qualquer outra coisa. Havia uma tranquilidade na maneira como estavam juntos, uma atenção que não precisava de muitas palavras.

Pensei em quantas viagens teriam feito lado a lado. Eu não conhecia a história dos dois, e não poderia adivinhá-la apenas olhando para eles. Mas aquele gesto eu podia ver: em meio ao movimento de um avião cheio, continuavam encontrando tempo para se acariciar.

Soube que viajavam todos os anos para aquelas praias. O trabalho ao longo do ano era estressante, e as férias eram uma oportunidade de descanso. Só algum tempo depois descobri que eram donos de uma rede de hotéis em várias capitais do Mercosul.

Naquele primeiro momento, porém, eram apenas seu Jorge e dona Ana, sorridentes, sentados perto de mim. Gostei de conhecê-los assim. Antes de saber o que possuíam ou o que faziam, eu já havia percebido o carinho que tinham um pelo outro.

Esses encontros fizeram o começo da viagem ficar mais agradável. Eu estava indo conhecer praias, mas já havia alguma coisa para observar ali mesmo, antes de chegarmos ao destino. Cada passageiro trazia sua própria vida, suas preocupações, seus planos. Por algumas horas, nossos caminhos seguiam na mesma direção.

De minha poltrona, eu observava o movimento de quem ainda se ajeitava. Uma bagagem precisava encontrar espaço, alguém se acomodava melhor, outra pessoa olhava em volta. Havia aquele cuidado de deixar tudo por perto antes da partida. Eu também queria me sentir confortável para as horas que viriam.

O destino era o mesmo, mas a viagem começava de um jeito para cada um. Para a família do outro lado do corredor, era uma experiência compartilhada entre os três. Para seu Jorge e dona Ana, fazia parte de um costume que repetiam todos os anos. Para mim, havia o prazer de sair da rotina e a curiosidade de ver o que encontraria quando chegasse.

Fiquei mais um pouco pensando no casal ao meu lado. Não era a idade, por si só, que me impressionava. Era a delicadeza de um gesto tão simples quanto manter as mãos unidas. Eu não precisava transformar aquilo numa história perfeita. Desconhecia o que haviam vivido, as dificuldades que talvez tivessem enfrentado. O que me tocava era o carinho que demonstravam naquele instante.

Às vezes, a gente só percebe uma coisa bonita porque está com tempo para olhar. Em um dia apressado, talvez eu nem tivesse reparado. Ali, sentado, esperando o avião partir, o gesto encontrou lugar na minha atenção. Guardei aquela imagem sem imaginar que continuaria me lembrando dela ao final das férias.

Também havia algo de agradável na maneira como conversavam. Não tentavam ocupar todo o assunto, nem pareciam preocupados em impressionar alguém. Eu me sentia à vontade perto deles. Podia perguntar alguma coisa, ouvir uma resposta e deixar que a conversa descansasse um pouco antes de continuar.

Não era preciso fazer amizade para sempre para que um encontro valesse a pena. Algumas pessoas passam por nós durante poucas horas e ainda assim deixam uma impressão boa. Eu já estava contente por dividir aquele começo de viagem com gente tão gentil.

Meus pensamentos foram interrompidos pelo alto-falante. O comandante deu as boas-vindas aos passageiros, desejou uma boa viagem e falou das férias nas Bahamas. Depois, chamou nossa atenção para as orientações da comissária de bordo.

Acompanhei as explicações sobre os procedimentos de segurança. Em seguida, o comandante informou que teríamos aproximadamente seis horas de voo. O tempo estava ensolarado, com boa visibilidade: céu de brigadeiro.

Fiquei tranquilo. Sabia que poderia haver alguma turbulência durante o trajeto, mas aquela notícia sobre o tempo me deixou mais à vontade. A expectativa de chegar também ajudava. Eu tinha quinze dias pela frente e queria aproveitá-los.

Enquanto esperava a decolagem, repassei mentalmente a ideia daqueles dias. Queria caminhar, conhecer as praias, sair um pouco dos horários habituais. Ainda não sabia quais lugares me agradariam mais, nem com quem acabaria conversando. Essa parte estava em aberto, e eu gostava de deixar alguma coisa por descobrir.

Planejar uma viagem é agradável, mas chega uma hora em que a gente quer parar de imaginar e começar a viver. Eu já me sentia nessa passagem. As providências para chegar até ali tinham ficado para trás; agora, acomodado no avião, podia simplesmente seguir.

Pensei que quinze dias seriam suficientes para descansar sem precisar correr de um lado para outro. Não queria voltar com a sensação de ter passado por tudo e prestado atenção em quase nada. Era uma vontade que ainda aprenderia a cumprir, porque, na chegada, meu entusiasmo certamente falaria mais alto.

Por enquanto, bastava ouvir as orientações, ajeitar o corpo na poltrona e esperar. A viagem não dependia mais da minha pressa. Essa constatação me trouxe um sossego bom. Estávamos a caminho.

O avião decolou. Pouco depois, atingimos a altitude de cruzeiro. Quando foi permitido sair da poltrona, olhei para a frente da cabine. Quase todos continuavam sentados, com exceção de alguns passageiros que se movimentavam mais adiante.

Levantei para dar alguns passos pelo corredor e esticar o corpo. Ficar muito tempo sentado incomoda, e aquele pequeno movimento já trouxe alívio. Enquanto caminhava, observei os rostos ao redor. Em muitos deles havia uma felicidade parecida com a que eu sentia.

Talvez cada um estivesse imaginando uma coisa diferente: a praia, o hotel, o descanso, os dias longe do trabalho. Eu não sabia. Via apenas as pessoas ali, acomodadas em suas poltronas, e reconhecia em mim aquela disposição para deixar a rotina um pouco de lado.

Voltei ao meu lugar e me acomodei. O tempo passou depressa. Depressa demais, pelo menos para a minha percepção, porque só me dei conta de que a viagem terminara quando o alto-falante voltou a anunciar uma mensagem aos passageiros.

O avião já estava em terra. Agradeciam pela viagem e nos desejavam uma ótima estada. Devo ter cochilado, talvez dormido por um bom tempo, pois não percebi as últimas horas passarem nem acompanhei o pouso como esperava.

Assim que a porta foi aberta, os passageiros começaram a se levantar e a retirar seus pertences dos compartimentos acima das poltronas. Fiz o mesmo. Logo estava a caminho da saída do avião, agradecendo em pensamento pela viagem.

Eu havia chegado. As praias que, até então, ocupavam meus planos agora estavam ali, ao alcance dos próximos dias.

### 2. Os primeiros passos em Nassau

Depois dos procedimentos de desembarque, peguei minha mala e segui para a saída do aeroporto de Nassau, capital das Bahamas. Precisava de um táxi que me levasse ao hotel onde ficaria hospedado pelos próximos quinze dias.

O percurso era de aproximadamente seis quilômetros, segundo a informação que eu tinha. Durante o caminho, quase não desviei os olhos da janela. Queria ver as casas, as ruas, o movimento. Havia construções antigas e outras modernas ao longo da via, e eu me entretinha observando como tudo aparecia junto, compondo a cidade.

Vi também tendas com objetos à venda, principalmente peças de artesanato. Mesmo de passagem, chamavam minha atenção os detalhes do trabalho. Fiquei com vontade de olhar tudo com mais calma. Naquele instante, entretanto, ainda estava a caminho do hotel, e a cidade ia se apresentando aos poucos, pela janela do carro.

Eu tentava acompanhar tudo, mas algumas imagens passavam antes que pudesse observá-las direito. Quando me interessava por uma construção, o carro já seguia adiante. Logo aparecia outra coisa, e minha atenção mudava de lugar. Era um olhar de chegada, ainda sem referências, que acolhia as novidades conforme surgiam.

Os objetos nas tendas despertavam uma curiosidade diferente. Nas construções, eu via o lugar onde aquelas pessoas viviam e trabalhavam; nas peças de artesanato, imaginava o cuidado de quem se ocupava de fazê-las. Não sabia como eram produzidas, nem quanto tempo exigiam. Só conseguia notar que alguns detalhes pediam mais do que a olhada rápida que eu lhes dava de dentro do táxi.

Tive vontade de voltar depois, sem a mala e sem a preocupação de chegar ao hotel. Caminhando, poderia parar no ponto que me interessasse. O trajeto de carro era uma primeira aproximação. Eu ainda teria tempo de escolher o que ver mais de perto.

Também procurava entender o caminho, embora soubesse que não memorizaria tudo. Uma esquina chamava minha atenção, uma sequência de casas ficava na lembrança, e de repente eu já não sabia direito como ligá-las entre si. Não me preocupei. Conhecer uma cidade começava justamente por aceitar que, durante algum tempo, eu seria um visitante tentando se orientar.

Há uma curiosidade especial nesses primeiros minutos de chegada. O que para quem mora ali talvez seja apenas o caminho de todos os dias, para mim era novidade. Uma fachada, uma esquina, uma pequena loja: tudo merecia um olhar mais demorado.

Não demorou para chegarmos. Fiz os procedimentos da hospedagem e escolhi um apartamento voltado para o sol da manhã. Depois de entrar no quarto, meu plano era simples: tomar um banho rápido, trocar de roupa e sair.

Estar finalmente no quarto me deu a medida de que eu havia chegado de verdade. No avião, ainda estava em deslocamento; no táxi, atravessava a cidade. Ali eu tinha um lugar para deixar a mala e para onde voltar depois de cada passeio. Aquela seria minha referência pelos próximos dias.

Deixei minhas coisas, olhei o espaço e fui cuidar do que precisava antes de sair. Não queria perder muito tempo, mas também não havia motivo para fazer tudo correndo. Podia me arrumar com calma. A cidade continuaria lá quando eu estivesse pronto.

A escolha de um apartamento voltado para o sol da manhã me agradava. Eu gostava da ideia de começar os dias percebendo a claridade chegar. Nem todos teriam o mesmo programa, e talvez em alguns eu acordasse mais tarde. Ainda assim, era bom imaginar aquelas manhãs num lugar diferente do habitual.

O banho trouxe o alívio de encerrar as horas de viagem. Trocar de roupa ajudou a passar da sensação de passageiro para a de alguém que saía para conhecer o destino. Quando me preparei para ir, já estava pensando no primeiro caminho que faria, mesmo sem saber exatamente onde ele começaria ou terminaria.

Queria conhecer as praias, andar pela cidade, ver pessoas. Afinal, estava de férias. Haveria tempo para ficar no hotel, mas, naquele começo, a vontade de sair era maior.

Comecei a caminhar sem um rumo certo. Entrava numa rua, dobrava na próxima, seguia por outra e virava mais uma esquina. Não importava muito a ordem. Eu queria conhecer o lugar, andar entre as pessoas que circulavam por ali e descobrir o que havia adiante.

Gostava daquela liberdade de não precisar cumprir um compromisso a cada hora. Podia parar, olhar uma vitrine, seguir caminhando. Se uma rua despertava minha curiosidade, eu entrava. Se outra parecia mais convidativa, mudava de direção.

Na rotina, tantas vezes fazemos um trajeto pensando apenas na chegada. Naqueles passeios, o próprio caminho ocupava minha atenção. Eu estava ali para isso: olhar, conhecer, aproveitar. Não precisava transformar cada saída numa tarefa.

Também queria perceber a cidade para além do quarto onde dormiria. O hotel me oferecia conforto, mas era caminhando que eu começava a reconhecer os lugares. Uma viagem ficava mais próxima de mim quando eu podia percorrer suas ruas com meus próprios passos.

O que eu mais apreciava nessas primeiras caminhadas era poder mudar de ideia. Talvez seguisse pensando em chegar à praia e, no caminho, alguma coisa me fizesse diminuir o passo. Não tinha ninguém esperando por mim numa hora marcada. Podia me dar esse tempo sem precisar justificar a demora.

Havia gente que passava apressada e gente que, como eu, parecia estar passeando. Eu não conhecia suas razões, mas via como ritmos diferentes dividiam a mesma rua. Para alguns, aquele era um dia comum; para mim, era uma das tardes que eu esperara viver nas férias.

Essa diferença me ajudava a olhar o lugar com mais respeito. A cidade não existia apenas para quem chegava de visita. Havia trabalho, compromissos e vidas acontecendo enquanto eu passeava. Gostava de lembrar disso, porque me fazia prestar atenção no movimento sem tratar tudo como parte de um cenário preparado para mim.

Eu era um visitante, e isso também tinha seu encanto. Podia estranhar o que ainda não conhecia e sentir satisfação quando um caminho começava a fazer sentido. Bastava reconhecer uma esquina pela segunda vez para experimentar uma pequena confiança. Aos poucos, o lugar deixava de ser apenas novo e passava a ter pontos que eu já sabia encontrar.

Não precisava saber tudo sobre Nassau para gostar de estar ali. Naquele começo, conhecer significava percorrer, observar e permitir que alguma coisa ficasse. Haveria detalhes que eu esqueceria logo depois, e outros que voltariam à lembrança sem esforço. Eu ainda não sabia quais seriam.

Numa das noites, acabei ficando fora até a madrugada. Experimentei vários drinques e, quando percebi a hora, resolvi voltar. Já não me sentia em condições de continuar circulando sozinho. Era melhor retornar, tomar um banho e dormir.

Ainda tinha muitos dias para conhecer aquelas praias. Não precisava aproveitar tudo de uma vez. Foi o que pensei ao encerrar a noite. O entusiasmo era grande, mas eu também precisava descansar para aproveitar o dia seguinte.

### 3. O tempo das férias

Antes de dormir, deixei o despertador preparado. Quando acordei, levantei, fiz minha higiene pessoal e liguei para pedir o café da manhã no quarto. Meu plano de hospedagem cobria os quinze dias com tudo incluído, e eu queria aproveitar aquele conforto.

Pedi algumas frutas e um suco de laranja. Estava com a garganta seca depois dos drinques da noite anterior. Enquanto esperava o café, pensei que precisava me controlar um pouco mais nas próximas saídas. Queria aproveitar as férias inteiras, inclusive as manhãs.

O desconforto daquela manhã era pequeno, mas suficiente para me fazer pensar na noite anterior. Quando a gente está se divertindo, nem sempre acompanha direito o que está fazendo. Um drinque vem depois do outro, a conversa continua, e só mais tarde o corpo lembra que também participou da festa.

Não havia razão para transformar isso num grande assunto. Eu só precisava reconhecer que teria mais prazer nos passeios se me sentisse bem para fazê-los. Estava num lugar que desejava conhecer, e queria ter disposição para sair, caminhar e voltar contente ao fim do dia.

Deixei esse pensamento comigo enquanto esperava o café. A manhã não precisava começar num ritmo acelerado para ser aproveitada. Podia comer, me ajeitar e decidir depois o que faria. Um dos confortos daqueles dias era justamente ter essa escolha.

Receber o café no quarto era uma daquelas pequenas comodidades que eu apreciava. Não havia nada de complicado no pedido: frutas, suco, um pouco de sossego. Ainda assim, poder começar o dia daquela maneira fazia parte do prazer da viagem.

À tarde, saí para caminhar, aproveitar o sol e observar o movimento nas praias. Havia muita gente querendo desfrutar o mesmo lugar. Eu olhava ao redor e me divertia com as diferenças: cada pessoa parecia ter seu próprio jeito de passar as férias.

Alguns turistas estavam vermelhos como um pimentão. Ao vê-los, pensei na pressa de quem tenta aproveitar todo o sol de uma só vez. A pele avermelhada dava a impressão de que o entusiasmo havia passado da conta.

Fiquei imaginando o desconforto de vestir uma camisa, de encostar a pele em alguma coisa ou de se deitar à noite. Eu queria voltar com boas lembranças, caminhar no dia seguinte, continuar conhecendo os lugares. Não fazia sentido me exceder a ponto de perder essa disposição.

Aquela cena me fez pensar no meu próprio ritmo. Na noite anterior, eu havia experimentado vários drinques; agora via gente exagerando no sol. Era fácil chegar cheio de vontade e esquecer que as férias durariam muitos dias.

Eu podia aproveitar uma tarde e deixar outra para depois. Podia voltar a um lugar de que tivesse gostado. Havia tempo para caminhar, descansar, sair novamente. Aos poucos, fui encontrando uma maneira de desfrutar tudo sem tanta pressa.

Era uma mudança que acontecia nos pequenos gestos. Eu diminuía a caminhada quando queria observar melhor, aceitava a vontade de fazer uma pausa e deixava para outro momento aquilo que não cabia naquele dia. Não sentia que estava perdendo a viagem por causa disso. Ao contrário, percebia melhor o que tinha à minha frente.

O mar podia continuar bonito depois que eu me afastasse dele por algumas horas. Uma lanchonete não precisava ser visitada só porque estava no caminho. Era possível passar, reconhecer a vontade e voltar depois. Eu começava a me livrar daquela obrigação que às vezes inventamos até quando estamos de férias: a de aproveitar cada minuto como se houvesse alguém fazendo a contagem.

Essa pressa não vinha de ninguém ao meu redor. Era minha, nascida do entusiasmo de chegar. Tinha viajado para estar ali, e por isso queria conhecer muita coisa. Com o passar dos dias, fui entendendo que dar atenção a um passeio podia ser mais agradável do que terminar vários pensando no próximo.

Quando via os turistas com a pele tão vermelha, lembrava que a vontade de levar um resultado para casa também podia nos atrapalhar. Eu não precisava provar, pela cor da minha pele ou pela quantidade de saídas, que havia desfrutado as férias. Saber que me sentira bem já seria suficiente.

Continuei caminhando e observando. Em alguns momentos, a praia tinha mais movimento; em outros, minha atenção se demorava num detalhe que antes passara despercebido. Eu gostava de ter dias pela frente para rever as mesmas paisagens sem precisar olhá-las sempre do mesmo jeito.

Os dias seguintes passaram entre passeios, praias e paradas para comer alguma coisa. Visitei muitos dos lugares que estavam ao meu alcance. Conheci cantinhos da praia e entrei nas lanchonetes que despertavam minha vontade de ficar.

Foi então que comecei a reparar nas escolhas que fazemos quase sem perceber. Por que entrar numa lanchonete e passar direto por outra, se, à primeira vista, elas parecem oferecer coisas tão parecidas? O que nos faz olhar para um lugar e decidir que é ali?

Pensei nisso mais de uma vez. Talvez algum detalhe me lembrasse um ambiente em que eu já havia me sentido bem. A disposição das mesas, a aparência do balcão, o jeito do lugar. Nem sempre eu saberia explicar. Só percebia que tinha vontade de entrar.

Na minha cabeça, era como uma fotografia conhecida: alguma coisa parecia familiar, mesmo numa cidade onde eu acabara de chegar. Depois, se prestasse atenção, talvez encontrasse ali semelhanças com outros lugares de que gostava.

Era uma impressão minha, uma tentativa de entender por que escolhia este ou aquele ambiente. Não precisava chegar a uma resposta definitiva. Bastava reconhecer como era curioso estar tão longe de casa e ainda assim procurar, em alguns detalhes, uma sensação conhecida.

Eu gostava de descobrir novidades, mas também apreciava encontrar um lugar em que pudesse ficar à vontade. Depois de tantas ruas e paisagens diferentes, escolher onde sentar por alguns minutos era outra forma de fazer parte daquela viagem.

E assim os dias iam passando. Às vezes, parecia que eu havia acabado de chegar; em outras, já reconhecia caminhos que no começo eram inteiramente novos. As férias ganhavam suas pequenas referências, e eu começava a guardar lembranças que não cabiam apenas numa vista bonita da praia.

### 4. Uma manhã sem pressa

Naquela altura das férias, eu já não precisava sair com a mesma ansiedade dos primeiros dias. Continuava querendo conhecer os lugares, mas começava a gostar também de ficar um pouco mais em cada um deles. A novidade ainda estava ali. Eu apenas já não sentia necessidade de persegui-la a cada esquina.

Uma das manhãs me trouxe essa sensação com mais clareza. O apartamento voltado para o sol da manhã, o café e o tempo de me preparar antes de sair faziam parte de um começo de dia que eu vinha aprendendo a apreciar. Não havia nada extraordinário acontecendo. Talvez fosse justamente isso que me agradava.

Na vida de todos os dias, é comum fazer uma coisa pensando no que vem depois. Enquanto se toma café, pensa-se na saída; enquanto se caminha, pensa-se no horário de chegar. Ali, eu tentava me dar o direito de terminar uma coisa antes de começar outra. Podia comer com calma e só então pensar no passeio.

Ainda carregava um pouco do costume de me apressar. Às vezes, olhava o tempo como se estivesse atrasado para alguma obrigação e logo lembrava que não havia compromisso. Sorria comigo mesmo. Leva um tempo para o corpo acreditar que está de férias, mesmo depois que a mala já foi desfeita.

Quando saí, fui no ritmo que tinha vontade. Não precisava alcançar um ponto antes de determinado horário. Eu queria caminhar, observar a praia e passar uma parte da manhã ao ar livre. Era um programa simples, que cabia muito bem naquele dia.

O movimento das pessoas sempre me entretinha. Via quem passava sozinho, quem andava em companhia e quem parecia procurar um lugar onde ficar. Cada pequeno grupo se organizava de um jeito. Eu gostava de observar sem precisar saber tudo sobre eles, apenas reconhecendo a variedade de maneiras de desfrutar a mesma manhã.

Também procurava não confundir o que via com o que imaginava. Um rosto sério podia ser só um rosto descansando; uma pessoa calada podia estar perfeitamente satisfeita. Depois de passar tantos dias reparando nos outros, eu sabia que nem sempre uma expressão contava a história inteira.

Com seu Jorge e dona Ana, por exemplo, eu havia observado um carinho muito bonito. Isso era real dentro do que presenciara. O resto da vida dos dois continuava pertencendo a eles. Gostei de lembrar disso enquanto caminhava, porque me ajudava a apreciar os encontros sem exigir que cada pessoa se explicasse para mim.

Segui pela praia prestando atenção no espaço que se abria adiante. Em alguns trechos, minha vontade era continuar; em outros, bastava diminuir o passo. O mar permanecia ao lado do caminho, e o som da água acompanhava a caminhada. Eu não precisava levar aquela paisagem a lugar nenhum. Por alguns minutos, estar ali era suficiente.

Tinha ido às Bahamas para desfrutar as praias, e agora podia fazer isso sem transformar o passeio numa lista. Não era necessário marcar quantos pontos eu havia visto ou quanto tempo ficara em cada lugar. Algumas coisas seriam lembradas justamente porque eu lhes dera mais atenção do que planejara.

Havia uma diferença entre estar sozinho e sentir que faltava alguém. Naquela caminhada, eu estava bem com minha própria companhia. Podia escolher por onde seguir e deixar os pensamentos se acomodarem. Não havia urgência em conversar, embora eu soubesse que também gostava dos encontros que a viagem vinha trazendo.

Eu podia apreciar as duas situações. No avião, a conversa tinha sido agradável; em outros momentos, o silêncio me fazia bem. Não precisava decidir qual delas tornaria minhas férias melhores. Cada uma encontrava seu lugar conforme o dia passava.

Enquanto andava, pensei no quanto eu havia imaginado aquele destino antes de chegar. Mesmo sem uma programação rígida, trazia expectativas. Queria praias bonitas, descanso e a liberdade de sair da rotina. Agora estava vivendo essas coisas de uma maneira mais simples do que qualquer ideia formada à distância.

Não havia um momento único em que tudo se realizava. As férias aconteciam em pedaços: na disposição de levantar, no gosto do café, na escolha de um caminho, na satisfação de perceber que não precisava correr. Quando eu reunia tudo, via que estava aproveitando.

Mais adiante, voltei a reparar nos lugares onde poderia parar para comer. A questão das escolhas ainda me divertia. Eu me identificava com uma lanchonete, deixava outra para trás e às vezes nem sabia dizer o motivo. Naquele dia, resolvi prestar mais atenção à sensação antes de tentar explicá-la.

Um ambiente pode parecer acolhedor antes mesmo que a gente conheça alguém lá dentro. Talvez seja a maneira como o espaço está organizado ou a impressão de que poderemos nos acomodar sem pressa. Eu não tinha uma resposta exata. Tinha apenas vontade de escolher um lugar em que me sentisse bem.

Se, depois de entrar, a impressão se confirmava, era agradável perceber que podia confiar naquela pequena escolha. Se não acontecesse, haveria outros lugares e outras oportunidades. Estar de férias também me dava essa liberdade de não tratar uma decisão tão pequena como algo definitivo.

Com o passar dos dias, algumas dessas paradas se tornavam referências. Eu começava a lembrar onde ficava uma coisa, em qual direção devia seguir e que parte do caminho ainda queria percorrer. Não me sentia morador da cidade, nem pretendia conhecer a vida de quem morava ali. Era apenas o prazer de me orientar um pouco melhor.

O curioso era que um lugar continuava novo e, ao mesmo tempo, já podia me receber com alguma familiaridade. Eu reconhecia uma esquina e ainda tinha muito para ver depois dela. Essa combinação me agradava: havia segurança suficiente para caminhar à vontade e novidade suficiente para manter a curiosidade.

Pensei nas pessoas que viajavam todos os anos para as mesmas praias. Antes, talvez eu me perguntasse por que voltar ao lugar já conhecido quando existiam tantos outros destinos. Naquela manhã, consegui compreender um pouco da satisfação de retornar. Alguns lugares nos permitem descansar justamente porque não precisamos descobri-los inteiros outra vez.

Não sabia se faria dessas praias um costume, como seu Jorge e dona Ana. Ainda estava vivendo minha própria viagem e não precisava decidir as próximas. Mas entendi melhor o que podia atrair os dois. Reencontrar um lugar de que se gosta também tem seu prazer.

Continuei caminhando com esse pensamento, sem transformá-lo numa promessa. Era fácil, durante umas férias agradáveis, querer garantir que elas se repetiriam. Preferi me ocupar do dia que já tinha. Os outros, se viessem, encontrariam seu tempo.

Ao pensar no hotel, não senti que o passeio precisava continuar só para render mais. O quarto era parte do descanso que eu escolhera, e voltar não significava desperdiçar a manhã. Eu poderia sair novamente depois. Tinha aprendido um pouco a aceitar essas pausas.

Também percebi que nem toda boa lembrança nascia de uma surpresa. Às vezes, ela vinha da repetição tranquila de algo que nos agradava. Caminhar perto do mar por mais de um dia não tornava cada saída igual. Eu era outro em cada manhã: mais descansado, mais familiarizado com o lugar, com a atenção voltada para detalhes diferentes.

Foi assim que aquela manhã ficou na lembrança. Não por ter acontecido alguma coisa fora do comum, mas pela tranquilidade com que eu a vivi. Havia dias em que eu desejava sair e encontrar gente; naquele, gostei de acompanhar meus próprios passos.

Quando voltei, ainda havia bastante viagem pela frente. Eu me sentia satisfeito, sem a impressão de ter deixado alguma obrigação por cumprir. O que fizera cabia no que eu queria daquele dia. Mais tarde haveria outros passeios, conversas e lugares. Naquele momento, eu já tinha aproveitado uma boa manhã.

### 5. Lugares que a amizade revela

No hotel, conheci algumas pessoas muito agradáveis. Entre elas havia um grupo de argentinos, com casais e solteiros. Éramos cerca de quinze pessoas, e aos poucos comecei a fazer amizade com aquele pessoal.

Foi muito bom ter encontrado o grupo. Alguns visitavam aquelas praias com frequência e conheciam lugares que eu dificilmente descobriria por conta própria. Comecei a acompanhá-los nos passeios e, com eles, cheguei a recantos menos frequentados.

Até então, eu vinha conhecendo o lugar do meu jeito: caminhando, escolhendo uma rua, seguindo o que me chamava a atenção. Gostava dessa liberdade. Com os novos amigos, tive a oportunidade de fazer outros caminhos e aproveitar o conhecimento de quem já estivera ali.

Percebi como uma companhia podia mudar o alcance de um passeio. Eu continuava no mesmo destino, mas passava a conhecer partes dele que ainda não havia visto. Bastava seguir com pessoas que sabiam um pouco mais para que surgissem outras possibilidades.

Em alguns momentos, saímos dos pontos mais movimentados e visitamos cantinhos escondidos, pouco frequentados. A companhia tornou aqueles passeios ainda mais agradáveis. Tenho certeza de que muitos daqueles lugares teriam ficado fora das minhas lembranças se eu estivesse sozinho.

Alugamos um carro para chegar aos recantos mais distantes da praia. Era uma maneira de ampliar nossos passeios e conhecer um pouco mais do que havia por ali. Ao final da tarde, voltamos para o hotel.

Eu estava contente. A viagem havia começado com conversas no avião e, agora, continuava com outras pessoas, outros encontros. Não tinha planejado aquelas amizades antes de sair de casa, mas elas já faziam parte das minhas férias.

A convivência foi me mostrando como era agradável dividir uma descoberta. Quando eu passeava sozinho, escolhia tudo conforme minha vontade. Em grupo, também precisava acompanhar o ritmo dos outros. Havia uma troca nessa diferença: eu abria mão de decidir cada caminho e, em compensação, conhecia lugares aos quais não teria chegado.

Alguns sabiam onde ir e se orientavam com uma facilidade que eu ainda não tinha. Para eles, determinados trechos já eram conhecidos. Eu acompanhava e observava, contente por ter encontrado pessoas dispostas a compartilhar o que sabiam. Um destino parecia se ampliar quando alguém apontava outra possibilidade de passeio.

Ser acolhido por um grupo assim fazia diferença. Eu não precisava chegar sabendo o nome de cada lugar ou fingindo uma intimidade que ainda não existia. Podia dizer que estava conhecendo, ouvir e seguir junto. Aos poucos, deixava de me sentir alguém que apenas acompanhava e passava a me sentir parte daquela companhia.

Também gostava de ver como as pessoas se ajeitavam numa convivência de férias. Havia casais e solteiros, gente mais falante e gente que preferia ouvir. Não era preciso que todos fossem iguais para que os passeios dessem certo. Bastava haver espaço para cada um participar à sua maneira.

Eu me sentia bem no meio deles. Em certos momentos, entrava mais na conversa; em outros, ficava observando os lugares. Não precisava estar falando o tempo inteiro para aproveitar a companhia. A presença dos outros já tornava o passeio diferente, mesmo quando eu passava alguns minutos em silêncio.

O que guardo daquela turma é essa disposição para estar junto. Não penso nas férias como uma sequência de apresentações formais, mas nas oportunidades em que as pessoas se aproximavam e continuavam o dia em boa companhia. Foi assim que me vi saindo com o grupo e gostando de conhecer mais um pouco com eles.

Quando voltávamos ao hotel, o dia parecia ter rendido de outro jeito. Eu podia lembrar do lugar visitado e também de como havia sido bom estar acompanhado. O passeio terminava, mas ainda ficava a satisfação da convivência. Era diferente de voltar de uma caminhada sozinho, e eu gostava das duas experiências.

Pensei no quanto dependemos de estar disponíveis para conversar. No avião, bastou uma apresentação. No hotel, a convivência foi aproximando o grupo. As amizades não surgiram de um grande acontecimento; começaram no contato entre pessoas que estavam passando alguns dias no mesmo lugar.

Mais tarde, saímos para aproveitar a noite. Um dos jovens da turma conhecia bem a região e nos levou a uma balada à beira-mar. Ventava, e estava um pouco frio, mas isso não atrapalhou a nossa festa.

Conversamos com várias pessoas. Também houve paqueras e aquela animação de quem saiu para se divertir. Eu aproveitava a companhia, o lugar, a noite que tínhamos pela frente. Estava de férias e me sentia bem ali.

No fim, cada um seguiu sozinho para o seu descanso. A noite havia sido boa do jeito que foi. Nem toda conversa precisava continuar depois, nem toda aproximação precisava se transformar em alguma coisa. Eu já tinha vivido momentos agradáveis e conhecido gente interessante.

Nos dias que se seguiram, continuei visitando lugares bonitos e aproveitando o que aquelas férias ofereciam. Quando pensava nos passeios, lembrava também das pessoas com quem havia estado. O grupo de argentinos, seu João e Cleide, Marcelo, seu Jorge e dona Ana: cada encontro ocupava um lugar diferente na lembrança.

Havia uma coisa em comum entre essas pessoas tão diferentes: todas tinham me permitido conhecer um pouco delas. Algumas, durante o voo; outras, em vários passeios. Ninguém precisava me oferecer uma grande história para se tornar parte da minha. Bastavam uma conversa agradável e a maneira como eu me sentira naquele encontro.

Pensei novamente no primeiro momento, quando ainda estava sentado no avião e disse meu nome à família do outro lado do corredor. Naquela apresentação, não sabia o que viria depois. Não fazia ideia de que, ao recordar as férias, voltaria também a esse começo tão simples.

Agora eu entendia por que gostava de conversar durante uma viagem. A gente pode conhecer paisagens em silêncio, mas são as pessoas que tantas vezes nos ajudam a chegar um pouco mais perto do lugar. Foi com o grupo que encontrei recantos diferentes, e foi com os outros passageiros que comecei a me sentir em viagem antes mesmo de pousar.

Também sabia que cada um guardaria lembranças próprias. Talvez eu fosse, para alguém, apenas a pessoa com quem dividiu um passeio ou algumas palavras no avião. Tudo bem. Não era necessário ocupar um lugar maior na vida dos outros para reconhecer o valor que aqueles momentos tinham para mim.

As praias eram lindas, mas não era só da paisagem que eu me recordaria. Havia as conversas, os sorrisos, a gentileza e os caminhos que alguém me ajudara a conhecer. Tudo isso acompanharia as imagens que eu levava comigo.

### 6. Presentes e lembranças

Os últimos dias chegaram sem que a viagem perdesse o encanto. Eu ainda gostava de sair, olhar o movimento e aproveitar a praia. Ao mesmo tempo, comecei a pensar nos presentes que queria levar. Era uma parte do passeio que me aproximava, aos poucos, da volta para casa.

Comprar alguma coisa para mim era guardar uma lembrança escolhida naquele lugar. Para a família e os amigos, o gesto tinha outro gosto. Eu olhava para os objetos e pensava em quem poderia recebê-los, tentando encontrar algo que combinasse com cada pessoa.

Não precisava ser um presente grande. O que me interessava era reconhecer ali um motivo para me lembrar de alguém. Algumas peças chamavam minha atenção pelo trabalho, outras por uma aparência que me agradava. Entre olhar e escolher, eu passava um tempo imaginando a chegada e a oportunidade de entregá-las.

O artesanato voltou a despertar minha curiosidade, como havia acontecido no trajeto do aeroporto para o hotel. Daquela vez, porém, eu já não olhava tudo pela janela de um carro em movimento. Podia dar mais atenção aos objetos, perceber os detalhes e considerar com calma o que desejava levar.

Gostava de pensar no cuidado que uma peça podia carregar, embora não conhecesse a história de quem a fizera. Não inventava uma para ela. Bastava notar o trabalho visível e escolher conforme o que me agradava. O objeto teria sua própria origem, e eu acrescentaria a lembrança do dia em que o encontrara.

Passei a observar de uma maneira diferente. Antes, meu interesse estava mais voltado para o lugar: o que ver, por onde andar, onde ficar um pouco. Agora, algumas coisas se tornavam possibilidades de presente. Uma parte da minha atenção continuava ali, nas férias; outra já procurava as pessoas de casa.

Percebi como elas haviam permanecido comigo, mesmo durante tantos dias longe. Não precisava estar pensando nelas o tempo inteiro para saber disso. Bastava ver alguma coisa que me fizesse lembrar de um gosto, de uma preferência, do prazer de oferecer um pequeno agrado.

Essa lembrança me trazia alegria. Eu havia saído para desfrutar meus dias, e estava fazendo isso. Ainda assim, era bom saber para quem desejava voltar e com quem tinha vontade de repartir as histórias. Uma viagem tão agradável ficava melhor quando eu pensava na possibilidade de contá-la depois.

Fui escolhendo os presentes sem querer que cada um explicasse o destino inteiro. Nenhum objeto seria capaz de fazer isso. A praia que eu vira, os caminhos que percorrera e as pessoas com quem conversara não caberiam numa compra. O presente podia acompanhar uma história; não precisava substituir o que eu tinha para contar.

Talvez, ao entregá-lo, eu me lembrasse do lugar onde o havia escolhido. A conversa poderia começar por ali e seguir para outras cenas. Eu diria que conheci uma família no avião, um casal muito gentil, um grupo que me levou a passeios diferentes. Uma lembrança puxaria outra, como acontece quando a gente volta contente de algum lugar.

Pensei em seu Jorge e dona Ana mais uma vez. Ao falar deles, provavelmente acabaria mencionando as mãos dadas antes de contar qualquer outra coisa. Era a imagem que permanecera comigo. O trabalho dos dois, as viagens anuais e a rede de hotéis vinham depois. Eu sabia que, na minha lembrança, aquele carinho seria o primeiro detalhe.

Com a família do outro lado do corredor, guardaria a facilidade da apresentação. Estávamos num avião, a caminho de férias, e em pouco tempo já podíamos conversar. Seu João, Cleide e Marcelo tinham participado daquele início sem precisar fazer nada além de estar presentes e ser gentis.

Já o grupo de argentinos me faria recordar os caminhos que eu não conhecia. Quando pensasse naquelas pessoas, viriam junto os passeios em companhia, o carro alugado para alcançar os recantos mais distantes e a noite à beira-mar. Era difícil separar a paisagem da experiência de ter estado com eles.

Enquanto escolhia o que levar, eu ia percebendo que essas lembranças não estavam organizadas como uma lista de dias. Não conseguia reunir tudo apenas dizendo o que fizera primeiro ou depois. Algumas cenas voltavam pela importância que tinham para mim, mesmo que eu não soubesse apontar imediatamente em qual dia aconteceram.

Isso não me incomodava. Eu não estava preparando um relatório das férias. Estava vivendo os últimos passeios e reconhecendo o que desejava guardar. As datas tinham seu lugar, mas a lembrança se ocupava de outras escolhas: um gesto, uma conversa, a sensação de andar sem pressa.

Também havia coisas que eu só notava melhor agora que a despedida se aproximava. Uma parte do caminho que se tornara habitual, o conforto de saber voltar ao hotel, a liberdade de decidir o que fazer naquela tarde. No começo, eu quase não prestara atenção ao prazer de ir me acostumando.

Tinha levado alguns dias para encontrar meu ritmo. Primeiro, quis sair depressa e conhecer tudo. Depois, entendi que podia fazer pausas, aproveitar a manhã ou acompanhar outras pessoas. Quando percebi, já me sentia à vontade naquela rotina de férias. E agora ela começava a chegar ao fim.

Não senti vontade de correr para compensar o tempo que passara. Ainda havia o que ver, certamente, mas também havia muita coisa que eu já desfrutara. Preferi aproveitar os dias que restavam com a mesma atenção que me fizera gostar dos anteriores.

Se voltasse a um trecho de praia, não precisaria procurar uma novidade só para justificar o passeio. Poderia gostar dele outra vez. Se escolhesse caminhar por uma rua conhecida, isso também faria parte da despedida. Eu já tinha minhas pequenas referências naquele lugar e sentia prazer em reconhecê-las.

Foi curioso perceber como se pode criar familiaridade em quinze dias. Não significava conhecer tudo. Eu sabia muito pouco da vida da cidade e de quem morava nela. Mas alguns caminhos haviam participado da minha experiência e, por isso, agora me pareciam próximos.

Comprei o que desejava levar e pensei no espaço da mala. Os presentes precisariam acompanhar as coisas que tinham vindo comigo. Era uma preocupação simples, ligada ao retorno, que me fazia lembrar da viagem de ida. Naquele dia, eu arrumara a bagagem pensando no que encontraria; agora, começava a cuidar dela pensando no que queria levar.

Havia também as lembranças que não exigiam espaço nenhum. Eu poderia esquecer algum detalhe ao contar, trocar a ordem de uma passagem e depois me corrigir. Ainda assim, reconheceria o que sentira. A felicidade daqueles dias não dependia de guardar cada minuto com exatidão.

Não queria fazer das férias uma coisa perfeita quando falasse sobre elas. Houve a manhã de garganta seca depois dos drinques e a necessidade de descansar. Houve escolhas pequenas, momentos de indecisão e passeios sem um destino muito claro. Tudo isso pertencia à viagem tanto quanto as praias bonitas.

Talvez fosse justamente essa mistura que a tornava tão minha. Eu não tinha vivido um conjunto de cenas prontas para serem contadas. Tinha caminhado, conversado, me cansado, descansado e seguido de novo. Agora podia olhar para esses dias e sentir satisfação pelo modo como haviam acontecido.

Ao pensar na chegada à minha cidade, não imaginava apenas a entrega dos presentes. Queria reencontrar as pessoas e retomar as conversas conhecidas. Depois de tanta novidade, começava a apreciar a ideia de estar num lugar onde não precisaria aprender o caminho para tudo.

Sentir essa vontade não diminuía meu prazer de estar nas Bahamas. Eu continuava contente com a viagem. Era possível gostar muito de um destino e, ainda assim, desejar a própria casa. As duas alegrias estavam presentes, e eu não precisava escolher entre elas.

Os presentes foram ficando prontos para acompanhar a volta, e eu continuei aproveitando os últimos dias. Quando pensava neles, já via uma ligação entre o lugar onde estava e aquele para onde iria. Eu havia escolhido aquelas coisas nas férias, mas era em casa que o gesto de oferecê-las se completaria.

Nessa altura, voltar já fazia parte dos meus pensamentos de uma maneira boa. Não era uma pressa para ir embora. Era a expectativa de encerrar dias felizes e chegar perto de quem eu gostava, levando o que havia comprado e, principalmente, o que tinha vivido.

Ainda desfrutei as praias e os passeios que aqueles dias permitiram. Aos poucos, fui me despedindo do lugar do meu jeito: olhando com atenção, reconhecendo o que me agradava e agradecendo pela oportunidade. Queria partir com essa sensação de ter estado ali de verdade, disponível para o que a viagem oferecera.

### 7. A felicidade de voltar

As duas semanas haviam passado, e meus quinze dias de viagem chegavam ao fim. Eu tinha aproveitado as praias, os passeios, as noites e as comodidades do hotel. Sentia-me muito feliz por tudo o que vivera ali.

Comprei presentes para mim, para minha família e para meus amigos. Escolher alguma coisa para levar era também pensar nas pessoas que faziam parte da minha vida. Mesmo longe, elas estavam presentes na vontade de chegar e repartir um pouco da alegria daqueles dias.

Eu queria levar lembranças do lugar, mas sabia que nem tudo poderia ir dentro da mala. Algumas coisas ficariam comigo de outra maneira: uma conversa, o carinho entre seu Jorge e dona Ana, a curiosidade dos primeiros passeios, os lugares que conheci com os novos amigos.

Quando a gente chega, quinze dias parecem bastante tempo. Há uma sensação boa de ter todas aquelas manhãs pela frente, de ainda não conhecer os caminhos, de poder escolher o que fazer. Depois, quase sem perceber, começamos a contar os dias que faltam para ir embora.

Eu não me arrependia de nada daquela viagem. Tinha conhecido lugares lindos e vivido momentos que guardaria com carinho. Ao pensar em tudo o que fizera, sentia gratidão pela oportunidade de ter estado ali.

Mesmo assim, estava feliz por voltar para minha cidade.

Eu reconhecia essa vontade nos pensamentos mais simples. Já não imaginava apenas o próximo passeio; também pensava em como seria bom chegar. Tinha feito as compras, guardado lembranças e vivido os dias que desejara. Agora havia uma outra expectativa ocupando espaço.

Lembrei do entusiasmo com que olhara pela janela do táxi na chegada. Queria ver tudo, quase sem piscar, receoso de perder uma novidade. A cidade aparecia em pedaços, e eu tentava juntar cada um deles. Quanta coisa havia acontecido desde aquele trajeto tão curto até o hotel.

As ruas continuavam pertencendo a Nassau, mas algumas já tinham passado a fazer parte da minha lembrança. Eu saberia reconhecer o sentimento de estar ali mesmo que não conseguisse descrever cada construção. O lugar havia deixado de ser apenas um destino imaginado para se tornar uma experiência que eu levava comigo.

Também voltei a pensar no quarto. Durante aqueles dias, ele fora o ponto ao qual eu retornava para descansar. Saía dali para a cidade e para as praias; depois, voltava com os pés cansados e a cabeça cheia de imagens. Gostara daquele conforto. Era bom reconhecer isso antes de me despedir.

No começo, imaginara que a parte principal das férias estaria sempre do lado de fora, nos passeios. Depois, aproveitei o café, a tranquilidade das manhãs e as pausas que me permitiram continuar disposto. Tudo tinha encontrado seu lugar. Eu me sentia contente por não ter passado os quinze dias apenas correndo de uma saída para outra.

Ao lembrar do voo, percebi também que havia partido aberto para conhecer pessoas. A apresentação à família, a gentileza do casal idoso e a amizade com os argentinos não eram coisas que eu poderia ter colocado numa programação antes de sair. Elas surgiram na convivência, e eu aceitei participar.

Gostei de pensar que tinha estado disponível para esses encontros. Poderia ter ficado mais fechado, preocupado somente com os lugares que desejava ver. Em vez disso, conversei, ouvi e acompanhei outras pessoas. As férias ganharam muito com essa disposição.

Eu não precisava levar uma promessa de reencontro de cada amizade para valorizar o que vivera. Algumas companhias pertencem ao tempo de uma viagem. Isso não as torna menos agradáveis. Naqueles dias, elas haviam feito parte da minha felicidade, e era com esse carinho que eu as recordava.

Era curioso sentir tanta alegria pelas férias e, ao mesmo tempo, desejar o retorno. Eu havia aproveitado aqueles dias de verdade. Gostara de estar longe, de caminhar por ruas diferentes, de conhecer pessoas. Agora, queria reencontrar meu lugar.

Talvez algumas coisas de casa ganhassem outra importância depois de tantos dias fora. Os caminhos conhecidos, a presença da família e dos amigos, a vida que eu havia deixado esperando. Nada disso precisava ser novidade para fazer falta.

Nas Bahamas, eu procurara praias e descanso. Encontrei também pequenas ocasiões para observar as pessoas e pensar na minha própria maneira de aproveitar o tempo. Houve momentos de animação e momentos tranquilos, passeios em companhia e caminhadas em que bastava minha curiosidade.

Eu lembraria dessas férias com alegria. Lembraria do mar, das ruas de Nassau, das tendas de artesanato, da liberdade de virar uma esquina sem ter um compromisso marcado. Lembraria das pessoas que dividiram um pedaço daqueles dias comigo.

Gostaria que, ao acompanhar este relato, você também pudesse imaginar um pouco dessas cenas: o corredor do avião, a janela do táxi, o movimento das praias e as saídas com os amigos. São essas lembranças que trago da viagem.

Estava imensamente feliz pelos dias que passei nas Bahamas. E, depois de tudo o que havia visto e aproveitado, havia uma felicidade ainda maior me esperando: voltar para casa, para o meu lugar.

Fim.
